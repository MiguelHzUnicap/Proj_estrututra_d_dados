void Free_Hash(Hash* tabela) {
    if (!tabela) return;    // Verifica se a tabela existe

    for (int i = 0; i < tabela->capacidade; i++) {
        Usuario* atual = tabela->p[i];
        while (atual != NULL) {
            Usuario* prox = atual->prox;
            free(atual);
            atual = prox;
        }
    }

    free(tabela->p);
    free(tabela);
}
